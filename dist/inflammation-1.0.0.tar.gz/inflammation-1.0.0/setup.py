# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['inflammation']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'inflammation',
    'version': '1.0.0',
    'description': 'Analyse patient inflammation data',
    'long_description': None,
    'author': 'SamuelHLewis',
    'author_email': 'samuel.h.lewis@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
